/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuanpertama1;

/**
 *
 * @author win 10
 */
public class Hewan extends MakhlukHidup {
    private int JumlahKaki;
    private String Bergerak;
    private String Habitat; 

    /**
     * @return the JumlahKaki
     */
    public int getJumlahKaki() {
        return JumlahKaki;
    }

    /**
     * @param JumlahKaki the JumlahKaki to set
     */
    public void setJumlahKaki(int JumlahKaki) {
        this.JumlahKaki = JumlahKaki;
    }

    /**
     * @return the Bergerak
     */
    public String getBergerak() {
        return Bergerak;
    }

    /**
     * @param Bergerak the Bergerak to set
     */
    public void setBergerak(String Bergerak) {
        this.Bergerak = Bergerak;
    }

    /**
     * @return the Habitat
     */
    public String getHabitat() {
        return Habitat;
    }

    /**
     * @param Habitat the Habitat to set
     */
    public void setHabitat(String Habitat) {
        this.Habitat = Habitat;
    }

}