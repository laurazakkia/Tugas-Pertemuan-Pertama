/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuanpertama1;

/**
 *
 * @author win 10
 */
public class Tumbuhan extends MakhlukHidup {
    private String WarnaDaun;
    private String ArahDaun;
    private String LingkunganHidup;
    private int biji;

    /**
     * @return the WarnaDaun
     */
    public String getWarnaDaun() {
        return WarnaDaun;
    }

    /**
     * @param WarnaDaun the WarnaDaun to set
     */
    public void setWarnaDaun(String WarnaDaun) {
        this.WarnaDaun = WarnaDaun;
    }

    /**
     * @return the ArahDaun
     */
    public String getArahDaun() {
        return ArahDaun;
    }

    /**
     * @param ArahDaun the ArahDaun to set
     */
    public void setArahDaun(String ArahDaun) {
        this.ArahDaun = ArahDaun;
    }

    /**
     * @return the LingkunganHidup
     */
    public String getLingkunganHidup() {
        return LingkunganHidup;
    }

    /**
     * @param LingkunganHidup the LingkunganHidup to set
     */
    public void setLingkunganHidup(String LingkunganHidup) {
        this.LingkunganHidup = LingkunganHidup;
    }    

    /**
     * @return the biji
     */
    public int getBiji() {
        return biji;
    }

    /**
     * @param biji the biji to set
     */
    public void setBiji(int biji) {
        this.biji = biji;
    }
}