/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuanpertama1;

/**
 *
 * @author win 10
 */
public class Mamalia extends Hewan {
    private String CaraBerkembangbiak;
    private String JenisMakanan;

    /**
     * @return the JenisMakanan
     */
    public String getJenisMakanan() {
        return JenisMakanan;
    }

    /**
     * @param JenisMakanan the JenisMakanan to set
     */
    public void setJenisMakanan(String JenisMakanan) {
        this.JenisMakanan = JenisMakanan;
    }

    /**
     * @return the CaraBerkembangbiak
     */
    public String getCaraBerkembangbiak() {
        return CaraBerkembangbiak;
    }

    /**
     * @param CaraBerkembangbiak the CaraBerkembangbiak to set
     */
    public void setCaraBerkembangbiak(String CaraBerkembangbiak) {
        this.CaraBerkembangbiak = CaraBerkembangbiak;
    }   
}