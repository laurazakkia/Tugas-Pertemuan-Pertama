/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuanpertama1;

/**
 *
 * @author win 10
 */
public class Monokotil extends Tumbuhan {
    private String BentukBatang;
    private String BentukDaun;

    /**
     * @return the BentukBatang
     */
    public String getBentukBatang() {
        return BentukBatang;
    }

    /**
     * @param BentukBatang the BentukBatang to set
     */
    public void setBentukBatang(String BentukBatang) {
        this.BentukBatang = BentukBatang;
    }

    /**
     * @return the BentukDaun
     */
    public String getBentukDaun() {
        return BentukDaun;
    }

    /**
     * @param BentukDaun the BentukDaun to set
     */
    public void setBentukDaun(String BentukDaun) {
        this.BentukDaun = BentukDaun;
    }
}
