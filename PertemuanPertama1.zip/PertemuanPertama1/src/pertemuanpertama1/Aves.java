/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuanpertama1;

/**
 *
 * @author win 10
 */
public class Aves extends Hewan {
    private String BentukParuh;
    private String BentukKaki;
    private String BentukSayap;

    /**
     * @return the BentukParuh
     */
    public String getBentukParuh() {
        return BentukParuh;
    }

    /**
     * @param BentukParuh the BentukParuh to set
     */
    public void setBentukParuh(String BentukParuh) {
        this.BentukParuh = BentukParuh;
    }

    /**
     * @return the BentukKaki
     */
    public String getBentukKaki() {
        return BentukKaki;
    }

    /**
     * @param BentukKaki the BentukKaki to set
     */
    public void setBentukKaki(String BentukKaki) {
        this.BentukKaki = BentukKaki;
    }

    /**
     * @return the BentukSayap
     */
    public String getBentukSayap() {
        return BentukSayap;
    }

    /**
     * @param BentukSayap the BentukSayap to set
     */
    public void setBentukSayap(String BentukSayap) {
        this.BentukSayap = BentukSayap;
    }
    
    
}
