/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuanpertama1;

/**
 *
 * @author win 10
 */
public class Amfibi extends Hewan {
    private String TeksturKulit;
    private String OrganPernafasan;

    /**
     * @return the TeksturKulit
     */
    public String getTeksturKulit() {
        return TeksturKulit;
    }

    /**
     * @param TeksturKulit the TeksturKulit to set
     */
    public void setTeksturKulit(String TeksturKulit) {
        this.TeksturKulit = TeksturKulit;
    }

    /**
     * @return the OrganPernafasan
     */
    public String getOrganPernafasan() {
        return OrganPernafasan;
    }

    /**
     * @param OrganPernafasan the OrganPernafasan to set
     */
    public void setOrganPernafasan(String OrganPernafasan) {
        this.OrganPernafasan = OrganPernafasan;
    }
}
