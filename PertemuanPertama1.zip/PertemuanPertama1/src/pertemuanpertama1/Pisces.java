/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuanpertama1;

/**
 *
 * @author win 10
 */
public class Pisces extends Hewan {
    private String BentukSirip;
    private String BentukInsang;

    /**
     * @return the BentukSirip
     */
    public String getBentukSirip() {
        return BentukSirip;
    }

    /**
     * @param BentukSirip the BentukSirip to set
     */
    public void setBentukSirip(String BentukSirip) {
        this.BentukSirip = BentukSirip;
    }

    /**
     * @return the BentukInsang
     */
    public String getBentukInsang() {
        return BentukInsang;
    }

    /**
     * @param BentukInsang the BentukInsang to set
     */
    public void setBentukInsang(String BentukInsang) {
        this.BentukInsang = BentukInsang;
    }

}