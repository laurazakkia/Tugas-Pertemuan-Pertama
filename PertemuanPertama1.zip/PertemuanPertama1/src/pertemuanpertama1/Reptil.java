/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuanpertama1;

/**
 *
 * @author win 10
 */
public class Reptil extends Hewan {
    private String BentukSisik;
    private String BentukKepala;

    /**
     * @return the BentukSisik
     */
    public String getBentukSisik() {
        return BentukSisik;
    }

    /**
     * @param BentukSisik the BentukSisik to set
     */
    public void setBentukSisik(String BentukSisik) {
        this.BentukSisik = BentukSisik;
    }

    /**
     * @return the BentukKepala
     */
    public String getBentukKepala() {
        return BentukKepala;
    }

    /**
     * @param BentukKepala the BentukKepala to set
     */
    public void setBentukKepala(String BentukKepala) {
        this.BentukKepala = BentukKepala;
    }
   
}