/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuanpertama1;

/**
 *
 * @author win 10
 */
public class MakhlukHidup {
        public void bernafas(){
        System.out.println("Saya Bernafas...");
    }
        public void tumbuh(){
        System.out.println("Saya Tumbuh...");
    }
        public void berkembangbiak(){
        System.out.println("Saya dapat berkembangbiak...");
    }
        public void makan(){
        System.out.println("Saya membutuhkan makan sebagai sumber energi");
    }
}