/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuanpertama1;

/**
 *
 * @author win 10
 */
public class Dikotil extends Tumbuhan {
    private String BentukAkar;
    private String BentukBunga;

    /**
     * @return the BentukAkar
     */
    public String getBentukAkar() {
        return BentukAkar;
    }

    /**
     * @param BentukAkar the BentukAkar to set
     */
    public void setBentukAkar(String BentukAkar) {
        this.BentukAkar = BentukAkar;
    }

    /**
     * @return the BentukBunga
     */
    public String getBentukBunga() {
        return BentukBunga;
    }

    /**
     * @param BentukBunga the BentukBunga to set
     */
    public void setBentukBunga(String BentukBunga) {
        this.BentukBunga = BentukBunga;
    }
}
